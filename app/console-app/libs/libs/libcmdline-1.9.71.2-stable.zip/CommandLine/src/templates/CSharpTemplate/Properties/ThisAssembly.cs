#region License
// <copyright file="ThisAssembly.cs" company="Your name here">
//   Copyright 2013 Your name here
// </copyright>
//
// [License Body Here]
#endregion


static class ThisAssembly
{
    internal const string Title = "CSharpTemplate";
    internal const string Author = "Your name here";
    internal const string Copyright = "Copyright (C) 2013 " + Author;
    internal const string Version = "1.0.0.0";
    internal const string InformationalVersion = "1.0.0-alfa"; // http://semver.org
}
