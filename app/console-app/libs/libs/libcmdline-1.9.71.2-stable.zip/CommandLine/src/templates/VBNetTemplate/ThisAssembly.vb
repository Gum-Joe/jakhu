﻿#Region "License"
'<copyright file="ThisAssembly.vb" company="Your name here">
'   Copyright 2013 Your name here
' </copyright>
'
' [License Body Here]
#End Region

Friend Class ThisAssembly
    Friend Shared Title As String = "VBNetTemplate"
    Friend Shared Author As String = "Your Name Here"
    Friend Shared Copyright As String = "Copyright (C) 2012 " + Author
    Friend Shared Version As String = "1.0.0.0" ''alfa?
    Friend Shared InformationalVersion As String = "1.0"
End Class
